let currentSong;

function playSelectedSong(songId) {
    if (currentSong && currentSong !== songId) {
        document.getElementById(currentSong).pause();
    }

    currentSong = songId;
    playOrPause();
}

function playOrPause() {
    const song = document.getElementById(currentSong);
    const controls = document.getElementById('universal-controls');
    const button = controls.querySelector('button');

    if (!song) return; // No song has been selected yet

    if (song.paused) {
        song.play();
        button.textContent = 'Pause';
        controls.style.display = 'block';
    } else {
        song.pause();
        button.textContent = 'Play';
    }
}

// For song seeking
document.addEventListener("DOMContentLoaded", function() {
    const seekBar = document.getElementById('universal-seek');
    
    seekBar.addEventListener("change", function() {
        const song = document.getElementById(currentSong);
        if (song) {
            song.currentTime = seekBar.value;
        }
    });

    setInterval(() => {
        const song = document.getElementById(currentSong);
        if (song && !song.paused) {
            seekBar.max = song.duration;
            seekBar.value = song.currentTime;
        }
    }, 1000);
});
